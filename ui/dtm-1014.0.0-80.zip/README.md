# Cumulocity solution enablement mono repository

This repository contains the Solution Enablement team projects.

## Getting staerted

1. install `yarn`
2. run `yarn install`
3. start `yarn serve` to serve all current packages.

## Workspace

This mono repo is using yarn workspaces. More information can be found here:
https://yarnpkg.com/features/workspaces

Adding dependencies or running commands on a certain package need you to prefix the command with `workspace`. For example:
`yarn workspace digital-twin add lodash` -> will install lodash to digital twin
`yarn workspace machine-portal start`-> will run the start script of machine-portal package.
`yarn add rimraf -W` -> will add rimraf to the workspace root. This should be only considered for libs that are useful for managing the workspace.

Adding a new workspace can be archived by aligning the root package.json:

```json
"workspaces": [
  "packages/digital-twin",
  "packages/machine-portal",
  "packages/xyz"
],
```

## Testing
This mono repo is using jest to test. You can run test in watch mode by running `yarn test:watch`. Any file with the `.spec.ts` ending will be picked up for testing. The watch mode automatically tries to get the changed files by checking the git changes. However you can stop the execution and get more options by hitting `w` button and for example only run test by a certain file-match-pattern.
